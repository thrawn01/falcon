#!/usr/bin/env bash

rm -f $1/*.c
rm -f $1/*.so
rm -f $1/*.pyc
