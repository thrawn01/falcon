"""Falcon benchmarks"""

from bench import main  # NOQA
